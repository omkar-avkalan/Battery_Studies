import time
from PIL import Image, ImageDraw
from luma.core.interface.serial import spi
from luma.lcd.device import st7735

# SPI setup (Pi hardware SPI)
serial = spi(port=0, device=0, gpio_DC=24, gpio_RST=25)

# Create display object (1.44" ST7735, 128x128)
device = st7735(serial, width=128, height=128, rotation=0)

# Create image buffer
image = Image.new("RGB", (device.width, device.height), "black")
draw = ImageDraw.Draw(image)

# Draw test content
draw.rectangle((0, 0, 127, 127), outline="white")
draw.text((10, 20), "Raspberry Pi", fill="green")
draw.text((10, 40), "ST7735 OK", fill="white")

# Send to display
device.display(image)

print("TFT test image sent successfully")

# Keep image visible
while True:
    time.sleep(1)
