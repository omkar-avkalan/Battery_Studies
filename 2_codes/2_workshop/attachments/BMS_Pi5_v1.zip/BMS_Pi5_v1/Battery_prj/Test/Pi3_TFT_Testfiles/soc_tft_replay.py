#!/usr/bin/env python3
import time
import os

import numpy as np
import pandas as pd

from luma.core.interface.serial import spi
from luma.lcd.device import st7735
from luma.core.render import canvas


# ================== USER SETTINGS ==================
CSV_EKF = "/home/avkalan/Desktop/Battery_prj/3state_ekf/Charge/Results/ekf_full_output.csv"

# Scale factor for playback speed:
#  1.0 = real time (same as experiment)
#  2.0 = 2x faster, etc.
TIME_SCALE = 30.0

# Display size (adjust if your panel is different, e.g. 160x128)
WIDTH = 128
HEIGHT = 128
# ===================================================


def init_display():
    """
    Initialise ST7735 via luma.lcd.
    If your test script used different parameters, copy them here.
    """
    serial = spi(
        port=0,
        device=0,      # CE0
        gpio_DC=24,    # same pins you used in the test
        gpio_RST=25,
        bus_speed_hz=4000000,
    )
    device = st7735(serial, width=WIDTH, height=HEIGHT, rotate=0)
    return device


def load_ekf_csv(path):
    """
    Load EKF CSV and return (time_s, soc_hat) as numpy arrays.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"CSV not found: {path}")

    df = pd.read_csv(path)

    # Ensure columns exist
    required = {"time_s", "soc_hat"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"CSV is missing columns: {missing}")

    t = pd.to_numeric(df["time_s"], errors="coerce").to_numpy()
    soc = pd.to_numeric(df["soc_hat"], errors="coerce").to_numpy()

    # Clean NaNs
    mask = np.isfinite(t) & np.isfinite(soc)
    t = t[mask]
    soc = soc[mask]

    # Normalise time to start from 0
    if len(t) == 0:
        raise ValueError("No valid data in CSV.")
    t = t - t[0]

    return t, soc


def soc_to_percent(s):
    s = float(s)
    s = max(0.0, min(1.0, s))
    return int(round(s * 100.0))


def draw_frame(device, soc_value, t_seconds):
    """
    Draw one frame: SOC bar + text on TFT.
    """
    soc_pct = soc_to_percent(soc_value)

    with canvas(device) as draw:
        # Title
        draw.text((5, 5), "EKF SOC", fill="white")

        # SOC numeric
        draw.text((5, 25), f"{soc_pct:.3f} %", fill="white")

        # Simple horizontal bar
        bar_x0, bar_y0 = 5, 60
        bar_x1, bar_y1 = WIDTH - 5, 85
        draw.rectangle((bar_x0, bar_y0, bar_x1, bar_y1), outline="white")

        bar_max_w = bar_x1 - bar_x0 - 4
        bar_fill_w = int(bar_max_w * (soc_pct / 100.0))
        if bar_fill_w < 0:
            bar_fill_w = 0

        # Colour: green normally, red if very low
        fill_color = "green" if soc_pct > 20 else "red"
        draw.rectangle(
            (bar_x0 + 2, bar_y0 + 2, bar_x0 + 2 + bar_fill_w, bar_y1 - 2),
            fill=fill_color,
        )

        # Time label
        draw.text((5, 95), f"t = {t_seconds:6.1f} s", fill="white")


def main():
    print("Loading EKF CSV from:", CSV_EKF)
    t, soc = load_ekf_csv(CSV_EKF)
    print(f"Loaded {len(t)} samples.")
    print("Initial time span:", t[0], "to", t[-1], "seconds")

    device = init_display()
    print("TFT initialised, starting SOC replay... (Ctrl+C to stop)")

    # Start replay
    t0_wall = time.time()
    last_t_sim = t[0]

    for k in range(len(t)):
        t_sim = t[k]
        soc_k = soc[k]

        # Draw current frame
        draw_frame(device, soc_k, t_sim)

        # Compute sleep to roughly follow simulated time
        if k < len(t) - 1:
            dt_sim = (t[k + 1] - t[k]) / TIME_SCALE
            if dt_sim < 0:
                dt_sim = 0
        else:
            dt_sim = 0

        # Simple pacing
        if dt_sim > 0:
            time.sleep(float(dt_sim))

    print("Replay complete.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped by user.")
