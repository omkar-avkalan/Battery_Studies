
from luma.core.interface.serial import spi
from luma.lcd.device import st7735
from luma.core.render import canvas
from PIL import ImageFont
import time

# SPI interface
serial = spi(port=0, device=0, gpio_DC=24, gpio_RST=25)

# Create device (adjust rotation if needed)
device = st7735(
    serial,
    width=128,
    height=128,
    rotation=0
)

font = ImageFont.load_default()

while True:
    with canvas(device) as draw:
        draw.rectangle(device.bounding_box, outline="white", fill="black")
        draw.text((10, 10), "Raspberry Pi", fill="white", font=font)
        draw.text((10, 30), "ST7735 OK", fill="green", font=font)
        draw.text((10, 50), "SOC: 76%", fill="white", font=font)
    time.sleep(1)
