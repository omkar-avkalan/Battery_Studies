import time
import RPi.GPIO as GPIO
from luma.core.interface.serial import spi
from luma.lcd.device import st7735
from luma.core.render import canvas

RESET_PIN = 25
DC_PIN = 24

# Setup GPIO manually for the deep reset
GPIO.setmode(GPIO.BCM)
GPIO.setup(RESET_PIN, GPIO.OUT)

print("Forcing Hard Reset...")
GPIO.output(RESET_PIN, GPIO.LOW)
time.sleep(2)  # Critical 2-second hold for stalled controllers
GPIO.output(RESET_PIN, GPIO.HIGH)
time.sleep(1)

# Lower SPI speed (4MHz) is more stable for budget Xcluma boards
print("Re-initializing SPI at 4MHz...")
serial = spi(port=0, device=0, gpio_DC=DC_PIN, gpio_RST=RESET_PIN, baudrate=4000000)

# Use st7735 for 128x128
device = st7735(serial, width=128, height=128)

try:
    with canvas(device) as draw:
        draw.rectangle(device.bounding_box, outline="white", fill="red")
        draw.text((30, 50), "RESET SUCCESS", fill="white")
    print("If screen is still white, re-seat your GND wire.")
except Exception as e:
    print(f"Error: {e}")
finally:
    GPIO.cleanup()
