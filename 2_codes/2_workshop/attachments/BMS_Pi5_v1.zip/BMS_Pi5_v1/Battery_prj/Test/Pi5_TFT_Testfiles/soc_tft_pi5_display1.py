#!/usr/bin/env python3
import time
import os
import numpy as np
import pandas as pd
from datetime import timedelta

from luma.core.interface.serial import spi
from luma.lcd.device import st7735
from luma.core.render import canvas


# ================= USER SETTINGS =================
CSV_EKF = "/home/avkalan/Desktop/Battery_prj/3state_ekf/Charge/Results/ekf_full_output.csv"
TIME_SCALE = 30.0

WIDTH = 128
HEIGHT = 128

GPIO_DC = 24
GPIO_RST = 25
# ================================================


def init_display():
    serial = spi(
        port=0,
        device=0,
        gpio_DC=GPIO_DC,
        gpio_RST=GPIO_RST,
        bus_speed_hz=4000000
    )
    device = st7735(serial, width=WIDTH, height=HEIGHT, rotate=0)
    return device


def load_ekf_csv(path):
    if not os.path.exists(path):
        raise FileNotFoundError(path)

    df = pd.read_csv(path)
    t = df["time_s"].to_numpy()
    soc = df["soc_hat"].to_numpy()

    t = t - t[0]
    return t, soc


def soc_to_percent(soc):
    return int(np.clip(soc, 0.0, 1.0) * 100)


def format_time(seconds):
    return str(timedelta(seconds=int(seconds)))


def draw_battery_icon(draw, percent):
    x, y, w, h = 5, 5, 28, 12

    draw.rectangle((x, y, x + w, y + h), outline="white")
    draw.rectangle((x + w + 1, y + 4, x + w + 4, y + h - 4), fill="white")

    fill_w = int((w - 4) * percent / 100)
    color = "green" if percent > 20 else "red"

    draw.rectangle(
        (x + 2, y + 2, x + 2 + fill_w, y + h - 2),
        fill=color
    )


def draw_frame(device, soc, t_sim):
    soc_pct = soc_to_percent(soc)
    temp_c = 28.5  # placeholder (bind real sensor later)
    time_str = format_time(t_sim)

    with canvas(device) as draw:
        # Battery icon
        draw_battery_icon(draw, soc_pct)

        # Charge text
        draw.text((40, 6), "Charge", fill="white")
        draw.text((40, 18), f"{soc_pct} %", fill="yellow")

        # Temperature bottom-left
        draw.text((2, HEIGHT - 15), f"T: {temp_c:.1f}C", fill="white")

        # Time bottom-right
        draw.text((WIDTH - 70, HEIGHT - 15), time_str, fill="white")


def main():
    print("Loading EKF CSV...")
    t, soc = load_ekf_csv(CSV_EKF)
    print(f"Loaded {len(t)} samples")

    device = init_display()
    print("TFT initialised (Pi 5)")

    for k in range(len(t)):
        draw_frame(device, soc[k], t[k])

        if k < len(t) - 1:
            dt = (t[k + 1] - t[k]) / TIME_SCALE
            if dt > 0:
                time.sleep(dt)

    print("Replay complete")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Stopped")
