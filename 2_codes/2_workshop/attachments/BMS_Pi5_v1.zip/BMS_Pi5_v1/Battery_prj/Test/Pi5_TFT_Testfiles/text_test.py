from luma.core.interface.serial import spi
from luma.lcd.device import st7735
from luma.core.render import canvas
from PIL import ImageFont
import time

# 1. Initialize SPI: 
# DC (Data/Command) is typically GPIO 24, RST (Reset) is GPIO 25
serial = spi(port=0, device=0, gpio_DC=24, gpio_RST=25)

# 2. Initialize the ST7735 device for 128x128
# If your screen colors look inverted, add: bgr=True
device = st7735(serial, width=128, height=128, rotate=0)

def main():
    print("Testing display... Check your screen.")
    while True:
        with canvas(device) as draw:
            # Draw a border
            draw.rectangle(device.bounding_box, outline="white", fill="black")
            
            # Simple text output
            draw.text((10, 40), "Avkalan labs pvt ltd", fill="blue")
            draw.text((10, 60), "Pi 5 Active", fill="white")
            
            # Placeholder for your future SoC data
            draw.text((10, 90), "SoC: xx%", fill="cyan")
            
        time.sleep(5)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass

