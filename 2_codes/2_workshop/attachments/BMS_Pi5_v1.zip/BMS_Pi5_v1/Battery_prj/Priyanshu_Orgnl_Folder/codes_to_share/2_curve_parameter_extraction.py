import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt
import os

# ===== USER SETTINGS =====
csv_file = "HPPC\Curve_1C_dis_25.csv"  # point this to your file
dt_CB = 9.95
initial_guesses = [0.039, 0.01459, 0.5, 30]  # [U1_0, U2_0, tau1, tau2]
lookup_table = "HPPC\parameters_1C_dis_25.csv"
t_insert = 0.0498
pulse_to_analyze = 1  # Change this to analyze different pulses (1 to 10)
# =========================

# --- load CSV ---
df = pd.read_csv(csv_file)
df.columns = [c.strip().lower() for c in df.columns]

# find time/voltage/current columns (flexible substring match)
t_col = next((c for c in df.columns if "time" in c), None)
v_col = next((c for c in df.columns if "volt" in c), None)
i_col = next((c for c in df.columns if "curr" in c), None)

if not all([t_col, v_col, i_col]):
    raise ValueError("CSV must contain time, voltage and current columns (names containing 'time','volt','curr').")

# Ensure numeric conversion for key columns. Coerce invalid strings (e.g. ' ') to NaN
# then drop rows that don't have valid numeric time/voltage/current values.
df[t_col] = pd.to_numeric(df[t_col], errors='coerce')
df[v_col] = pd.to_numeric(df[v_col], errors='coerce')
df[i_col] = pd.to_numeric(df[i_col], errors='coerce')

# Drop rows missing any of the essential numeric measurements
df = df.dropna(subset=[t_col, v_col, i_col]).reset_index(drop=True)

# Now create numpy arrays (dtype=float) from the cleaned dataframe
time = df[t_col].to_numpy(dtype=float)
voltage = df[v_col].to_numpy(dtype=float)
current = df[i_col].to_numpy(dtype=float)

# detect mode column robustly using pandas string ops (handles NaN/object)
mode_col = None
for c in df.columns:
    if ("type" in c) or ("mode" in c) or ("cc/" in c):
        mode_col = c
        break

if not mode_col:
    raise ValueError("Mode/type column not found in the data")

# Function to analyze a single pulse
def analyze_pulse(start_idx, end_idx, time, voltage, current, mode_series):
    local_time = time[start_idx:end_idx]
    local_voltage = voltage[start_idx:end_idx]
    local_current = current[start_idx:end_idx]
    local_mode = mode_series[start_idx:end_idx]
    
    print(f"\nAnalyzing pulse data from index {start_idx} to {end_idx}")
    
    # Detect rest and discharge periods
    dis_mask = local_mode.str.contains("cc/d", case=False, na=False).to_numpy(bool)
    rest_mask = local_mode.str.contains("cc/r", case=False, na=False).to_numpy(bool)
    
    # Print sequence of states for debugging
    states = []
    for i in range(len(local_mode)):
        if rest_mask[i]:
            states.append("REST")
        elif dis_mask[i]:
            states.append("DISCHARGE")
        if len(states) > 0 and (i == 0 or states[-1] != states[-2]):
            print(f"State at {i}: {states[-1]}")
    
    # Find the first discharge block
    dis_idx = np.where(dis_mask)[0]
    if dis_idx.size < 2:
        raise RuntimeError(f"No discharge found in pulse data")
    
    diffs = np.diff(dis_idx)
    splits = np.where(diffs > 1)[0]
    blocks = np.split(dis_idx, splits + 1)
    dis_block = next((b for b in blocks if len(b) >= 2), None)
    if dis_block is None:
        raise RuntimeError("No continuous discharge block with >=2 samples.")
    
    d0 = dis_block[0]
    end_dis = dis_block[-1]
    
    # Find last rest sample BEFORE discharge
    rest_before = np.where(rest_mask & (np.arange(len(rest_mask)) < d0))[0]
    last_rest_idx = rest_before[-1] if rest_before.size > 0 else max(0, d0 - 1)
    V_before = local_voltage[last_rest_idx]
    V_d0 = local_voltage[d0]
    I_pulse = abs(local_current[d0])
    
    if I_pulse == 0:
        raise RuntimeError("Zero current at the first discharge sample (I_pulse=0).")
    R0 = (V_before - V_d0) / I_pulse
    
    # Recovery: first rest block after discharge
    rest_after = np.where(rest_mask & (np.arange(len(rest_mask)) > end_dis))[0]
    if rest_after.size == 0:
        raise RuntimeError("No recovery rest after discharge found.")
    r_diffs = np.diff(rest_after)
    r_splits = np.where(r_diffs > 1)[0]
    r_blocks = np.split(rest_after, r_splits + 1)
    rec_block = r_blocks[0]
    
    # Extract recovery data
    t_rec_raw = local_time[rec_block] - local_time[rec_block[0]]
    v_rec_raw = local_voltage[rec_block].copy()
    
    # Clean data: remove any NaN or infinite values
    valid_mask = ~(np.isnan(t_rec_raw) | np.isnan(v_rec_raw) | 
                  np.isinf(t_rec_raw) | np.isinf(v_rec_raw))
    t_rec_raw = t_rec_raw[valid_mask]
    v_rec_raw = v_rec_raw[valid_mask]
    
    # Insert corrected point and process recovery data
    if len(t_rec_raw) < 2:
        raise RuntimeError("Not enough valid recovery samples to perform insertion/removal.")
    
    V_insert = v_rec_raw[0] + I_pulse * R0
    
    # Remove any values before t_insert (they might be problematic)
    mask_after_insert = t_rec_raw > t_insert
    t_rec_trim = t_rec_raw[mask_after_insert]
    v_rec_trim = v_rec_raw[mask_after_insert]
    
    if len(t_rec_trim) < 2:
        raise RuntimeError(f"Not enough valid data points after t_insert={t_insert}s")
    
    # Insert point at t=0 and shift other points by t_insert
    t_rec_new = np.insert(t_rec_trim - t_insert, 0, 0)  # First point at 0, others shifted back
    v_rec_new = np.insert(v_rec_trim, 0, V_insert)
    
    # Additional data validation
    if np.any(np.isnan(v_rec_new)) or np.any(np.isinf(v_rec_new)):
        raise RuntimeError("Invalid values (NaN/inf) found in voltage data after processing")
    
    # Ensure times are non-decreasing
    if not np.all(np.diff(t_rec_new) >= -1e-12):
        order = np.argsort(t_rec_new)
        t_rec_new = t_rec_new[order]
        v_rec_new = v_rec_new[order]
    
    # Fit the model
    U_OC = v_rec_new[-1]
    
    def voltage_model(t, U1_0, U2_0, tau1, tau2):
        return U_OC - U1_0 * np.exp(-t / tau1) - U2_0 * np.exp(-t / tau2)
    
    popt, pcov = curve_fit(voltage_model, t_rec_new, v_rec_new,
                          p0=initial_guesses,
                          bounds=([0,0,1e-6,1e-6],[np.inf,np.inf,1e6,1e7]),
                          maxfev=60000)
    U1_0, U2_0, tau1, tau2 = popt
    
    # Calculate parameters
    R1 = U1_0 / (I_pulse * (1 - np.exp(-dt_CB / tau1)))
    R2 = U2_0 / (I_pulse * (1 - np.exp(-dt_CB / tau2)))
    C1 = tau1 / R1
    C2 = tau2 / R2
    
    # Calculate residuals
    residuals = v_rec_new - voltage_model(t_rec_new, *popt)
    rms = np.sqrt(np.mean(residuals**2))
    
    # Create results dictionary
    results = {
        "t_rec_new": t_rec_new,
        "v_rec_new": v_rec_new,
        "voltage_model": voltage_model,
        "popt": popt,
        "R0": R0,
        "R1": R1,
        "R2": R2,
        "C1": C1,
        "C2": C2,
        "U1_0": U1_0,
        "U2_0": U2_0,
        "tau1": tau1,
        "tau2": tau2,
        "rms": rms,
        "V_before": V_before,
        "V_d0": V_d0,
        "I_pulse": I_pulse
    }
    
    return results

# Find all pulses in the data
mode_series = df[mode_col].astype(str)
rest_mask = mode_series.str.contains("cc/r", case=False, na=False)
dis_mask = mode_series.str.contains("cc/d", case=False, na=False)

# Find pulses by identifying complete sequences of rest-discharge-rest-discharge
pulses = []
segment_counter = 0
current_pulse_start = 0
current_state = None
previous_state = None
state_changes = []  # For debugging

print("\nAnalyzing state transitions:")
print("=" * 50)

# First, find the first rest period to start from
for i in range(len(mode_series)):
    if mode_series.iloc[i].strip().upper() == 'CC/R':
        current_pulse_start = i
        break

for i in range(current_pulse_start, len(mode_series)):
    # Determine current state
    current_value = mode_series.iloc[i].strip().upper()
    if current_value == 'CC/R':
        current_state = 'rest'
    elif current_value == 'CC/D':
        current_state = 'discharge'
    else:
        continue  # Skip other states
    
    # Detect state change
    if current_state != previous_state:
        if previous_state is not None:
            segment_counter += 1
            state_changes.append(f"Index {i}: {previous_state} -> {current_state} (Segment {segment_counter})")
        
        # After 4 segments (rest-discharge-rest-discharge), we have a complete pulse
        if segment_counter == 4:
            pulses.append((current_pulse_start, i))
            print(f"Pulse {len(pulses)} found: from index {current_pulse_start} to {i}")
            # Start new pulse
            current_pulse_start = i
            segment_counter = 0
    
    previous_state = current_state

# Add the last pulse if we have enough data
if segment_counter >= 3:  # Allow for slightly incomplete last pulse
    pulses.append((current_pulse_start, len(mode_series)))
    print(f"Last pulse {len(pulses)} found: from index {current_pulse_start} to {len(mode_series)}")

print("\nState changes detected:")
for change in state_changes:
    print(change)

print(f"\nTotal pulses found: {len(pulses)}")
print("=" * 50)

print(f"Found {len(pulses)} pulses in the data")

if pulse_to_analyze < 1 or pulse_to_analyze > len(pulses):
    raise ValueError(f"pulse_to_analyze must be between 1 and {len(pulses)}")

# Analyze the selected pulse
pulse_idx = pulse_to_analyze - 1
start_idx, end_idx = pulses[pulse_idx]
results = analyze_pulse(start_idx, end_idx, time, voltage, current, mode_series)

# Plot results
plt.figure(figsize=(9,5))
plt.plot(results["t_rec_new"], results["v_rec_new"], 'b.', label='Measured Recovery (with inserted point)')
plt.plot(results["t_rec_new"], results["voltage_model"](results["t_rec_new"], *results["popt"]), 'r-', label='2RC Fit')
#plt.axvline(x=t_insert, color='g', linestyle='--', label=f'Inserted {t_insert} s')
plt.xlabel("Time after recovery start [s]")
plt.ylabel("Voltage [V]")
plt.title(f"Voltage Relaxation Fit - Pulse {pulse_to_analyze}")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# Print results
print(f"\n=== Results for Pulse {pulse_to_analyze} ===")
print(f"I_pulse * R0 (V)           = {results['I_pulse'] * results['R0']:.8f}")
print(f"R0 (ohm)                   = {results['R0']:.8f}")
print(f"Fit RMS (V)                = {results['rms']:.8f}\n")
print(f"U1_0 (V)                   = {results['U1_0']:.8f}")
print(f"U2_0 (V)                   = {results['U2_0']:.8f}")
print(f"tau1 (s)                   = {results['tau1']:.8f}")
print(f"tau2 (s)                   = {results['tau2']:.8f}\n")
print(f"R1 (ohm)                   = {results['R1']:.8f}")
print(f"R2 (ohm)                   = {results['R2']:.8f}")
print(f"C1 (F)                     = {results['C1']:.8f}")
print(f"C2 (F)                     = {results['C2']:.8f}")

# Save to lookup table
row = {
    "Pulse_ID": pulse_to_analyze,
    "Ro_ohm": results["R0"],
    "R1_ohm": results["R1"],
    "C1_F": results["C1"],
    "tau1_s": results["tau1"],
    "R2_ohm": results["R2"],
    "C2_F": results["C2"],
    "tau2_s": results["tau2"],
    "V_before_discharge_V": results["V_before"],
    "V_d0_V": results["V_d0"],
    "I_pulse_A": results["I_pulse"],
    "fit_rms_V": results["rms"]
}

if os.path.exists(lookup_table):
    df_out = pd.read_csv(lookup_table)
    # Update or append row for this pulse
    mask = df_out['Pulse_ID'] == pulse_to_analyze
    if mask.any():
        # Ensure assignment shape matches DataFrame shape
        for col in row:
            df_out.loc[mask, col] = row[col]
    else:
        df_out = pd.concat([df_out, pd.DataFrame([row])], ignore_index=True)
else:
    df_out = pd.DataFrame([row])

df_out.to_csv(lookup_table, index=False)
print(f"\nSaved parameters for pulse {pulse_to_analyze} to:", lookup_table)