"""
combined_thevenin_pipeline.py

Inputs (edit top of file or pass via simple assignment):
 - SOC_OCV_FILE   : full SOC vs OCV csv (columns: SOC, OCV)
 - LUT_FILE       : LUT csv (columns at least: Pulse, OCV, I, Ro, r1, r2, c1, c2)
 - EXPERIMENT_CSV : experiment CSV (must contain Type, Time(Second), Voltage(V), Current(A))
 - NOMINAL_AH     : nominal capacity in Ah
 - MODE           : "charge" or "discharge"
 - EXPERIMENT_NAME: a short name used to name result folder/files

Output:
 - results/<HPPC_{rate_tag}_{MODE}/{experiment_name}>/ ... (yaml, sim csv, overlay, error, summary)
"""

import os
import shutil
import importlib
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ---------------- USER CONFIG (edit) ----------------
SOC_OCV_FILE = "SOC_45_dis.csv"
LUT_FILE = "2C_dis_45_parameters.csv"
EXPERIMENT_CSV = "Rearr_2C_disharge_HPPC_45.csv"   # experiment file to simulate
NOMINAL_AH = 52.5
MODE = "discharge"                # "discharge" or "charge"
EXPERIMENT_NAME = "2C_discharge_45"          # used for naming outputs
TMP_PARAMS = "params.yaml"        # temporary params used by thevenin
RESULTS_ROOT = "results"
# ---------------------------------------------------

# ---------- YAML generation helpers (from your working script) ----------
def fmt_list(lst, precision=None):
    if precision is not None:
        lst = [round(float(x), precision) for x in lst]
    else:
        lst = [float(x) for x in lst]
    if len(lst) <= 12:
        return "[" + ", ".join(repr(x) for x in lst) + "]"
    else:
        chunks = [lst[i:i+8] for i in range(0, len(lst), 8)]
        lines = []
        for c in chunks:
            lines.append("  " + ", ".join(repr(x) for x in c) + ",")
        body = "\n".join(lines)
        return "[\n" + body + "\n]"

def make_eval_block_text(xs, ys):
    xs_text = fmt_list(xs, precision=6)
    ys_text = fmt_list(ys, precision=6)
    block = (
        "(lambda xs, ys: (lambda soc, T_cell: (lambda np=__import__('numpy'): "
        "np.interp(np.asarray(soc, float), np.asarray(xs, float), np.asarray(ys, float), "
        "left=ys[0], right=ys[-1]) ) ( )))(\n"
        f"  {xs_text},\n"
        f"  {ys_text}\n"
        ")"
    )
    return block

def make_eval_block_text_ocv(xs, ys):
    xs_text = fmt_list(xs, precision=6)
    ys_text = fmt_list(ys, precision=6)
    block = (
        "(lambda xs, ys: (lambda soc: (lambda np=__import__('numpy'): "
        "np.interp(np.asarray(soc, float), np.asarray(xs, float), np.asarray(ys, float), "
        "left=ys[0], right=ys[-1]) ) () ))(\n"
        f"  {xs_text},\n"
        f"  {ys_text}\n"
        ")"
    )
    return block

def generate_yaml(lut_path, sococv_path, output_yaml, nominal_ah):
    lut_df = pd.read_csv(lut_path)
    sococv_df = pd.read_csv(sococv_path)

    # Normalize headings
    lut_df.columns = [c.strip() for c in lut_df.columns]
    sococv_df.columns = [c.strip() for c in sococv_df.columns]

    # Basic checks
    required_lut_cols = {"OCV", "Pulse", "I", "Ro", "r1", "r2", "c1", "c2"}
    if not required_lut_cols.issubset(set(lut_df.columns)):
        raise ValueError(f"LUT file must contain columns: {sorted(required_lut_cols)}. Found: {list(lut_df.columns)}")
    required_sococv_cols = {"SOC", "OCV"}
    if not required_sococv_cols.issubset(set(sococv_df.columns)):
        raise ValueError(f"SOC_vs_OCV file must contain columns: {sorted(required_sococv_cols)}. Found: {list(sococv_df.columns)}")

    # Prepare SOC-OCV curve (sorted by SOC)
    sococv_df = sococv_df.sort_values("SOC").reset_index(drop=True)
    soc_curve = sococv_df["SOC"].astype(float).tolist()
    ocv_curve = sococv_df["OCV"].astype(float).tolist()

    # Interpolate LUT SOC from LUT OCV using full SOC-OCV curve
    ocv_x = np.asarray(ocv_curve, dtype=float)
    soc_y = np.asarray(soc_curve, dtype=float)
    sort_idx = np.argsort(ocv_x)
    ocv_x_sorted = ocv_x[sort_idx]
    soc_y_sorted = soc_y[sort_idx]
    ocv_unique, unique_idx = np.unique(ocv_x_sorted, return_index=True)
    soc_for_unique_ocv = soc_y_sorted[unique_idx]

    lut_ocv_vals = lut_df["OCV"].astype(float).values
    lut_soc_interp = np.interp(lut_ocv_vals, ocv_unique, soc_for_unique_ocv,
                               left=soc_for_unique_ocv[0], right=soc_for_unique_ocv[-1])
    lut_df = lut_df.copy()
    lut_df["SOC_interp"] = lut_soc_interp
    lut_df = lut_df.sort_values("SOC_interp").reset_index(drop=True)

    # Extract arrays
    xs_ocv = soc_curve
    ys_ocv = ocv_curve
    xs_params = [float(round(x, 6)) for x in lut_df["SOC_interp"].tolist()]
    ys_Ro = [float(round(x, 8)) for x in lut_df["Ro"].tolist()]
    ys_R1 = [float(round(x, 8)) for x in lut_df["r1"].tolist()]
    ys_R2 = [float(round(x, 8)) for x in lut_df["r2"].tolist()]
    ys_C1 = [float(round(x, 6)) for x in lut_df["c1"].tolist()]
    ys_C2 = [float(round(x, 6)) for x in lut_df["c2"].tolist()]

    # Build YAML text (kept same structure as your script)
    header_lines = [
        "num_RC_pairs: 2",
        "soc0: 1.0",
        f"capacity: {nominal_ah:.2f}",
        "gamma: 0.0",
        "ce: 0.99",
        "mass: 1.9",
        "isothermal: false",
        "Cp: 700.0",
        "T_inf: 25.3",
        "h_therm: 12.0",
        "A_therm: 1.0",
        "",
    ]

    ocv_block = make_eval_block_text_ocv(xs_ocv, ys_ocv)
    Ro_block = make_eval_block_text(xs_params, ys_Ro)
    R1_block = make_eval_block_text(xs_params, ys_R1)
    C1_block = make_eval_block_text(xs_params, ys_C1)
    R2_block = make_eval_block_text(xs_params, ys_R2)
    C2_block = make_eval_block_text(xs_params, ys_C2)

    yaml_lines = []
    yaml_lines.extend(header_lines)
    yaml_lines.append("ocv: !eval |")
    yaml_lines.extend("  " + line for line in ocv_block.splitlines())
    yaml_lines.append("")
    yaml_lines.append("M_hyst: !eval |")
    yaml_lines.append("  (lambda soc: 0.0)")
    yaml_lines.append("")
    yaml_lines.append("R0: !eval |")
    yaml_lines.extend("  " + line for line in Ro_block.splitlines())
    yaml_lines.append("")
    yaml_lines.append("R1: !eval |")
    yaml_lines.extend("  " + line for line in R1_block.splitlines())
    yaml_lines.append("")
    yaml_lines.append("C1: !eval |")
    yaml_lines.extend("  " + line for line in C1_block.splitlines())
    yaml_lines.append("")
    yaml_lines.append("R2: !eval |")
    yaml_lines.extend("  " + line for line in R2_block.splitlines())
    yaml_lines.append("")
    yaml_lines.append("C2: !eval |")
    yaml_lines.extend("  " + line for line in C2_block.splitlines())
    yaml_lines.append("")

    Path(output_yaml).write_text("\n".join(yaml_lines))
    print(f"YAML created: {Path(output_yaml).resolve()}")
    print(f" - OCV block contains {len(xs_ocv)} SOC points (from {sococv_path})")
    print(f" - Parameter blocks contain {len(xs_params)} LUT points (from {lut_path})")
    return Path(output_yaml)

# ---------- Simulation helpers (from 3_Thevenin_sim.py, minimal edits) ----------
def load_experiment_csv(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Experimental CSV not found: {path}")
    raw = pd.read_csv(path, dtype=str)
    raw.columns = [c.strip() for c in raw.columns]
    lower = {c.lower(): c for c in raw.columns}
    tcol = lower.get("time(second)") or lower.get("time(s)") or lower.get("time_s") or lower.get("time")
    vcol = lower.get("voltage(v)") or lower.get("voltage") or lower.get("v")
    icol = lower.get("current(a)") or lower.get("current") or lower.get("i")
    typecol = lower.get("type")
    if not (tcol and vcol and icol and typecol):
        raise ValueError(f"CSV must contain Time, Voltage, Current, Type columns.")
    df = pd.DataFrame({
        "type": raw[typecol].replace(r'^\s*$', np.nan, regex=True),
        "time_s": pd.to_numeric(raw[tcol], errors="coerce"),
        "voltage_V": pd.to_numeric(raw[vcol], errors="coerce"),
        "current_A": pd.to_numeric(raw[icol], errors="coerce"),
    })
    return df

def split_into_segments(df):
    segments, current_indices, current_type = [], [], None
    for idx, row in df.iterrows():
        t = row["type"]
        if pd.isna(t):
            if current_indices:
                seg = df.loc[current_indices].copy().reset_index(drop=True)
                seg["seg_type"] = current_type
                segments.append(seg)
                current_indices, current_type = [], None
            continue
        t_norm = str(t).strip()
        if current_type is None:
            current_type = t_norm; current_indices = [idx]
        elif t_norm.lower() == str(current_type).lower():
            current_indices.append(idx)
        else:
            seg = df.loc[current_indices].copy().reset_index(drop=True)
            seg["seg_type"] = current_type
            segments.append(seg)
            current_type, current_indices = t_norm, [idx]
    if current_indices:
        seg = df.loc[current_indices].copy().reset_index(drop=True)
        seg["seg_type"] = current_type
        segments.append(seg)
    return segments

def infer_segment_info(seg_df):
    times = seg_df["time_s"].to_numpy(dtype=float)
    currents = seg_df["current_A"].to_numpy(dtype=float)
    seg_type = str(seg_df["seg_type"].iloc[0]).strip()
    duration = float(np.nanmax(times) - np.nanmin(times)) if np.isfinite(times).any() else 0.0
    valid_times = times[np.isfinite(times)]
    step = float(np.clip(np.median(np.diff(valid_times)), 0.001, 60.0)) if valid_times.size > 1 else 1.0
    current_A = 0.0
    for c in currents:
        if np.isfinite(c) and abs(c) > 1e-6:
            current_A = float(c); break
    return current_A, duration, step, seg_type

def infer_rate(nonzero_currents, nominal=NOMINAL_AH, test_mode="discharge"):
    # The same logic as your simulation script
    RATE = None  # we don't use external override here
    RATE_TOLERANCE = 0.25

    if RATE is not None:
        rate_int = int(RATE)
        base_name = f"params_{test_mode}_{rate_int}C.yaml"
        fallback = f"params_{rate_int}C.yaml"
        params = base_name if os.path.exists(base_name) else fallback
        return rate_int, params, rate_int

    if not nonzero_currents:
        fallback = f"params_{test_mode}_1C.yaml" if os.path.exists(f"params_{test_mode}_1C.yaml") else None
        return None, fallback or "params_1C.yaml", 0.0

    maxI = float(np.max(np.abs(nonzero_currents)))
    rate_float = maxI / nominal
    rate_round = int(round(rate_float))

    base_name = f"params_{test_mode}_{rate_round}C.yaml"
    fallback = f"params_{rate_round}C.yaml"
    params = base_name if os.path.exists(base_name) else fallback

    return rate_round, params, rate_float

def build_experiment(thev, selected_segments, mode_sign=1, verbose=True):
    expr = thev.Experiment(max_step=1)
    steps = []
    for seg in selected_segments:
        current_A, duration_s, step_s, seg_type = infer_segment_info(seg)
        if duration_s <= 0:
            continue
        step_current = float(mode_sign * current_A)
        steps.append((step_current, duration_s, step_s, seg_type))
        expr.add_step("current_A", step_current, (duration_s, step_s))
    if verbose:
        print("\n=== Simulation Steps Used ===")
        print("Idx | Current [A] | Duration [s] | Step [s] | Segment Type")
        for i, (I, dur, stp, typ) in enumerate(steps, 1):
            print(f"{i:>3} | {I:>12.5f} | {dur:>12.3f} | {stp:>8.3f} | {typ}")
        print("=============================================\n")
    return expr

def run_sim(thev, params_file, expr, tmp_params=TMP_PARAMS):
    tmp = tmp_params
    backup = None
    if os.path.exists(tmp):
        backup = tmp + ".bak"; shutil.copyfile(tmp, backup)
    shutil.copyfile(params_file, tmp)
    importlib.reload(thev)
    sim = thev.Simulation(params_file)
    soln = sim.run(expr)
    df_sim = pd.DataFrame(soln.vars)
    if backup and os.path.exists(backup): shutil.move(backup, tmp)
    else:
        try: os.remove(tmp)
        except FileNotFoundError: pass
    return df_sim

def save_and_plot(df_sim, exp_csv_path, out_dir, run_name):
    os.makedirs(out_dir, exist_ok=True)
    export_cols = [c for c in df_sim.columns if any(k in c.lower() for k in ("time","volt","current"))]
    if export_cols:
        df_sim[export_cols].to_csv(os.path.join(out_dir,"simulation_results.csv"),index=False)
    else:
        df_sim.to_csv(os.path.join(out_dir,"simulation_results.csv"),index=False)

    # extract sim arrays
    t_sim_h = df_sim.get("time_h", df_sim.get("time_s", pd.Series(np.arange(len(df_sim))))).to_numpy(dtype=float)
    if "time_s" in df_sim.columns: t_sim_h = df_sim["time_s"]/3600.0
    v_cols = [c for c in df_sim.columns if "volt" in c.lower()]
    v_sim = df_sim[v_cols[0]].to_numpy(float) if v_cols else np.array([])

    # experimental data
    try:
        exp = pd.read_csv(exp_csv_path)
        lc = {c.lower():c for c in exp.columns}
        tcol = lc.get("time(second)") or lc.get("time(s)") or lc.get("time")
        vcol = lc.get("voltage(v)") or lc.get("voltage") or lc.get("v")
        t_exp_s = pd.to_numeric(exp[tcol],errors="coerce")
        v_exp = pd.to_numeric(exp[vcol],errors="coerce")
        mask = np.isfinite(t_exp_s)&np.isfinite(v_exp)
        t_exp_h,v_exp=t_exp_s[mask]/3600.0,v_exp[mask]
    except Exception:
        t_exp_h=v_exp=None

    if v_sim.size and v_exp is not None:
        t_max=min(t_sim_h.max(),t_exp_h.max())
        mask=(t_exp_h>=0)&(t_exp_h<=t_max)
        v_sim_on_exp=np.interp(t_exp_h[mask],t_sim_h,v_sim)
        err=v_sim_on_exp-v_exp[mask]
        rmse=np.sqrt(np.mean(err**2))
        mae=np.mean(np.abs(err))
        mean_v=np.mean(v_exp[mask])
        rmse_pct=(rmse/mean_v*100) if mean_v else np.nan
        print(f"RMSE={rmse:.5f} V  |  {rmse_pct:.3f}% of mean {mean_v:.3f} V  |  MAE={mae:.5f} V")

        # overlay
        plt.figure(figsize=(9,5))
        plt.plot(t_exp_h,v_exp,label="Experiment",lw=2)
        plt.plot(t_sim_h,v_sim,"--",label="Simulation",lw=2)
        plt.xlabel("Time [h]");plt.ylabel("Voltage [V]")
        plt.title(f"Voltage Profile - {EXPERIMENT_NAME}");plt.legend();plt.grid(True)
        plt.savefig(os.path.join(out_dir,"voltage_profile.png"),dpi=150)
        plt.show()

        # error
        plt.figure(figsize=(9,4.5))
        plt.plot(t_exp_h[mask],err,lw=1.2)
        plt.fill_between(t_exp_h[mask],-0.01,0.01,alpha=0.1)
        plt.axhline(0,color="k",ls=":")
        plt.xlabel("Time [h]");plt.ylabel("Error [V]")
        plt.title(f"Error Profile - {EXPERIMENT_NAME}");plt.grid(True)
        plt.savefig(os.path.join(out_dir,"error_profile.png"),dpi=150)
        plt.show()

        return {"rmse": float(rmse), "rmse_pct": float(rmse_pct), "mae": float(mae)}
    else:
        print("No experimental data to compare; only simulation plotted.")
        plt.figure(figsize=(9,5))
        plt.plot(t_sim_h,v_sim,lw=2)
        plt.xlabel("Time [h]");plt.ylabel("Voltage [V]")
        plt.title(f"Simulation - {EXPERIMENT_NAME}");plt.grid(True)
        plt.savefig(os.path.join(out_dir,"simulation.png"),dpi=150);plt.close()
        return {"rmse": None, "rmse_pct": None, "mae": None}

# ---------- Main pipeline ----------
def main():
    # 1) generate yaml
    yaml_name = f"params_{EXPERIMENT_NAME}.yaml"
    yaml_path = generate_yaml(LUT_FILE, SOC_OCV_FILE, yaml_name, NOMINAL_AH)

    # 2) load experiment, split segments and select pulses (simulate ALL pulses)
    df = load_experiment_csv(EXPERIMENT_CSV)
    segs = split_into_segments(df)

    # Group every 4 segments into one pulse (original logic)
    total_pulses = len(segs) // 4
    if total_pulses == 0:
        raise ValueError("No valid pulses detected in the CSV file. Each pulse must have 4 segments.")

    pulses = [segs[i*4:(i+1)*4] for i in range(total_pulses)]
    sel = pulses[:]  # all pulses
    sel_segments = [s for p in sel for s in p]
    print(f"Total pulses detected: {total_pulses}. Simulating all pulses -> total segments: {len(sel_segments)}")

    # Current summary for rate detection
    currents = []
    for s in sel_segments:
        I, _, _, _ = infer_segment_info(s)
        if abs(I) > 1e-6:
            currents.append(abs(I))

    rate, params_file_guess, rate_float = infer_rate(currents, test_mode=MODE)
    rate_tag = f"{rate}C" if rate else f"{rate_float:.2f}C"

    mode_sign = 1 if MODE.lower() == "discharge" else -1

    out_dir = Path(RESULTS_ROOT) / f"HPPC_{rate_tag}_{MODE}" / EXPERIMENT_NAME
    out_dir.mkdir(parents=True, exist_ok=True)

    # save produced yaml in results folder (also used for sim)
    yaml_target = out_dir / yaml_path.name
    shutil.copyfile(yaml_path, yaml_target)

    print(f"Using YAML: {yaml_path} (copied to {yaml_target})")
    print(f"Results will be saved to: {out_dir}\n")

    # 3) run thevenin simulation using functions matching original script
    import thevenin as thev
    expr = build_experiment(thev, sel_segments, mode_sign=mode_sign)
    df_sim = run_sim(thev, str(yaml_path), expr)

    # 4) save and plot
    # Added experiment name to improve result naming
    run_name = f"{EXPERIMENT_NAME}_{Path(EXPERIMENT_CSV).stem}_{rate_tag}_{MODE}"
    metrics = save_and_plot(df_sim, EXPERIMENT_CSV, str(out_dir), run_name)

    # 5) save summary
    summary_file = out_dir / "summary.txt"
    with open(summary_file, "w") as fh:
        fh.write(f"experiment_name: {EXPERIMENT_NAME}\n")
        fh.write(f"experiment_csv: {EXPERIMENT_CSV}\n")
        fh.write(f"yaml_used: {yaml_target.name}\n")
        fh.write(f"mode: {MODE}\n")
        fh.write(f"rate_tag: {rate_tag}\n")
        fh.write(f"num_pulses: {total_pulses}\n")
        fh.write(f"rmse: {metrics.get('rmse')}\n")
        fh.write(f"rmse_pct: {metrics.get('rmse_pct')}\n")
        fh.write(f"mae: {metrics.get('mae')}\n")
    print(f"\nPipeline complete. All outputs in: {out_dir}")

if __name__ == "__main__":
    main()