import os
print("CWD =", os.getcwd())


import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt
import thevenin as thev 
import os


try:
    import scienceplots
    plt.style.use(["science", "ieee", "no-latex"])
except Exception:
    pass


def run_fullstate_ekf(
    #PARAMS_FILE="/Battery_prj/3state_ekf/Charge/params_1C_charge_25.yaml",
    #EXPERIMENT_CSV="/Battery_prj/3state_ekf/Charge/1C/ECh_1C.csv",
    PARAMS_FILE="Para_1c_25_dis.yaml",
    EXPERIMENT_CSV="Ch_1C.csv",
    
    DT=0.5,
    SOC0= 0.3535,
    T_CELL_DEFAULT=298.15,
    Q_diag=(1e-8, 1e-8, 1e-6),
    R_v=(3e-3) ** 2,
    P0_diag=(1e-4, 1e-4, 1e-3),
    D_OCV_DZ_EPS=1e-4,
    SOC_MIN=0.0,
    SOC_MAX=1.0,
    mode="c" # set c => charge & d => discharge
):

    pred = thev.Prediction(PARAMS_FILE)
    nRC = pred.num_RC_pairs
    assert nRC == 2, "This EKF implementation assumes exactly 2 RC pairs."

    ocv_fn = pred.ocv
    R0_fn = pred.R0
    R_funcs = [getattr(pred, f"R{j+1}") for j in range(nRC)]
    C_funcs = [getattr(pred, f"C{j+1}") for j in range(nRC)]

    df = pd.read_csv(EXPERIMENT_CSV)
    df.columns = [c.strip().lower() for c in df.columns]

    t = pd.to_numeric(df.get("time(s)", df.get("time_s", df.get("time"))), errors="coerce")
    I = pd.to_numeric(df.get("current", df.get("i", df.get("current(a)"))), errors="coerce")
    V = pd.to_numeric(df.get("voltage", df.get("v")), errors="coerce")

    #if mode=="d":
        #I = I  # discharge=+ve, charge=-ve
    #elif mode=="c": 
        #I = -I
    #else:
        #raise ValueError("Mode must be either charge or discharge ")
    I=-I
    

    if "temperature" in df.columns or "temperature_k" in df.columns:
        T_raw = pd.to_numeric(
            df.get("temperature_k", df.get("temperature")), errors="coerce"
        )
    else:
        T_raw = None

    mask = np.isfinite(t) & np.isfinite(I) & np.isfinite(V)
    t, I, V = t[mask], I[mask], V[mask]
    if T_raw is not None:
        T_raw = T_raw[mask]

    I_meas_raw = -I.copy()

    t0, t1 = float(t.min()), float(t.max())
    t_uni = np.arange(t0, t1, DT)
    t_uni = np.clip(t_uni, t0, t1)

    I_meas = np.interp(t_uni, t, I_meas_raw)
    V_meas = np.interp(t_uni, t, V)
    if T_raw is not None:
        T_meas = np.interp(t_uni, t, T_raw)
    else:
        T_meas = np.full_like(t_uni, T_CELL_DEFAULT)

    N = len(t_uni)

    x_hat = np.zeros(3, dtype=float)
    x_hat[2] = float(SOC0)

    P = np.diag(P0_diag).astype(float)
    Q = np.diag(Q_diag).astype(float)

    eta1_hist = np.zeros(N)
    eta2_hist = np.zeros(N)
    soc_hist = np.zeros(N)
    vhat_hist = np.zeros(N)
    innov_hist = np.zeros(N)
    K_hist = np.zeros((N, 3))
    P_diag_hist = np.zeros((N, 3))

    def predict_state(x, I_k, T_k, dt):
        st0 = thev.TransientState(
            soc=float(np.clip(x[2], 0.0, 1.0)),
            T_cell=float(T_k),
            hyst=0.0,
            eta_j=np.array([x[0], x[1]], dtype=float),
        )
        st1 = pred.take_step(st0, float(I_k), float(dt))
        x_next = np.array([st1.eta_j[0], st1.eta_j[1], st1.soc], dtype=float)
        return x_next

    t_start = time.time()
    t_last = t_start

    for k in range(N):
        I_k = float(I_meas[k])
        V_k = float(V_meas[k])
        T_k = float(T_meas[k])

        x_pred = predict_state(x_hat, I_k, T_k, DT)

        soc_for_params = float(np.clip(x_hat[2], 0.0, 1.0))
        Rj = np.array([Rf(soc_for_params, T_k) for Rf in R_funcs])
        Cj = np.array([Cf(soc_for_params, T_k) for Cf in C_funcs])

        tau = np.exp(-DT / (Rj * Cj))

        A = np.eye(3)
        A[0, 0] = tau[0]
        A[1, 1] = tau[1]
        A[2, 2] = 1.0

        P_pred = A @ P @ A.T + Q

        eta1_pred, eta2_pred, soc_pred = x_pred
        soc_pred_clip = float(np.clip(soc_pred, 0.0, 1.0))

        v_ocv = float(ocv_fn(soc_pred_clip))
        R0 = float(R0_fn(soc_pred_clip, T_k))
        v_hat = v_ocv - R0 * I_k - eta1_pred - eta2_pred

        z_p = float(np.clip(soc_pred_clip + D_OCV_DZ_EPS, 0.0, 1.0))
        z_m = float(np.clip(soc_pred_clip - D_OCV_DZ_EPS, 0.0, 1.0))
        dOCV_dz = (float(ocv_fn(z_p)) - float(ocv_fn(z_m))) / (2.0 * D_OCV_DZ_EPS)

        H = np.array([-1.0, -1.0, dOCV_dz])

        innov = V_k - v_hat

        S = H @ P_pred @ H.T + R_v
        S = float(max(S, 1e-12))

        K = (P_pred @ H) / S

        x_hat = x_pred + K * innov
        x_hat[2] = float(np.clip(x_hat[2], SOC_MIN, SOC_MAX))

        I3 = np.eye(3)
        KH = np.outer(K, H)
        P = (I3 - KH) @ P_pred @ (I3 - KH).T + R_v * np.outer(K, K)
        P = 0.5 * (P + P.T)

        eta1_hist[k] = x_hat[0]
        eta2_hist[k] = x_hat[1]
        soc_hist[k] = x_hat[2]
        vhat_hist[k] = v_hat
        innov_hist[k] = innov
        K_hist[k] = K
        P_diag_hist[k] = np.diag(P)

        now = time.time()
        if (now - t_last) > 5.0 or k == N - 1:
            pct = 100.0 * (k + 1) / N
            print(f"Progress: {pct:6.2f}% | step {k+1}/{N} | elapsed {now - t_start:5.1f}s", end="\r")
            t_last = now

    print(f"\nFull-state EKF complete | Runtime: {time.time() - t_start:.2f}s")

    df_out = pd.DataFrame(
        {
            "time_s": t_uni,
            "current_A": I_meas,
            "voltage_meas_V": V_meas,
            "voltage_pred_V": vhat_hist,
            "eta1_hat_V": eta1_hist,
            "eta2_hat_V": eta2_hist,
            "soc_hat": soc_hist,
            "innovation_V": innov_hist,
            "K_eta1": K_hist[:, 0],
            "K_eta2": K_hist[:, 1],
            "K_soc": K_hist[:, 2],
            "P_eta1": P_diag_hist[:, 0],
            "P_eta2": P_diag_hist[:, 1],
            "P_soc": P_diag_hist[:, 2],
        }
    )

    return df_out


def add_rc_currents(df, pred, T_cell=298.15):
    R1_fn = pred.R1
    R2_fn = pred.R2

    i_r1 = np.zeros(len(df))
    i_r2 = np.zeros(len(df))

    for k in range(len(df)):
        z = float(np.clip(df.loc[k, "soc_hat"], 0.0, 1.0))
        T_k = T_cell
        R1 = float(R1_fn(z, T_k))
        R2 = float(R2_fn(z, T_k))
        i_r1[k] = df.loc[k, "eta1_hat_V"] / R1
        i_r2[k] = df.loc[k, "eta2_hat_V"] / R2

    df["ir1_hat_A"] = i_r1
    df["ir2_hat_A"] = i_r2
    return df


if __name__ == "__main__":
    # charge => c & discharge => d 
    df = run_fullstate_ekf()
    pred = thev.Prediction("Para_1c_25_dis.yaml")
    df_ir = add_rc_currents(df, pred)
# ---------- Create output folder ----------
    outdir = "/home/avkalan/Desktop/Battery_prj/3state_ekf/Charge/Results"
    os.makedirs(outdir, exist_ok=True)


    plt.rcParams.update({
        "font.size": 18,            # base font size
        "axes.labelsize": 20,       # x/y labels
        "axes.titlesize": 22,       # title size
        "legend.fontsize": 18,      # legend text
        "xtick.labelsize": 16,
        "ytick.labelsize": 16,
        "lines.linewidth": 2.0,
        "figure.dpi": 300,          # keep high DPI but readable
    })






# ---------- Save all figures ----------
    rc_curr_fig = plt.figure(figsize=(8, 3))
    plt.plot(df_ir["time_s"], df_ir["ir1_hat_A"], label="i_r1_hat")
    plt.plot(df_ir["time_s"], df_ir["ir2_hat_A"], label="i_r2_hat")
    plt.legend()
    plt.xlabel("Time (s)")
    plt.ylabel("RC currents (A)")
    plt.title("RC Branch Currents")
    plt.tight_layout()
    rc_curr_fig.savefig(os.path.join(outdir, "rc_currents.png"), dpi=300)
    # plt.show(block=False)
    # plt.close(rc_curr_fig)

    voltage_err_fig = plt.figure(figsize=(8, 3))
    plt.plot(df["time_s"], df.voltage_meas_V - df.voltage_pred_V)
    plt.title("Voltage Prediction Error")
    plt.xlabel("Time (s)")
    plt.ylabel("Voltage Error (V)")
    plt.tight_layout()
    voltage_err_fig.savefig(os.path.join(outdir, "voltage_error.png"), dpi=300)
    plt.close(voltage_err_fig)

    soc_fig = plt.figure(figsize=(9, 5))
    plt.plot(df.time_s, df.soc_hat, linewidth=2)
    plt.title("SOC Estimate")
    plt.xlabel("Time (s)")
    plt.ylabel("SOC")
    plt.tight_layout()
    soc_fig.savefig(os.path.join(outdir, "soc_estimate.png"), dpi=300)
    plt.close(soc_fig)

    gain_fig = plt.figure(figsize=(9, 5))
    plt.plot(df.time_s, df["K_eta1"],"-" ,linewidth=0.5,label= "IR_1")
    plt.plot(df.time_s, df["K_eta2"],"-", linewidth=0.5,label= "IR_2",alpha=0.7 )
    plt.plot(df.time_s, df["K_soc"],"-", linewidth=0.5,label= "SOC")
    plt.title("EKF: Kalman Gain K_eta1")
    plt.xlabel("Time (s)")
    plt.ylabel("K_eta1")
    plt.legend( )
    plt.tight_layout()
    gain_fig.savefig(os.path.join(outdir, "kalman_gain_eta1.png"), dpi=300)
    plt.close(gain_fig)

    volt_fig = plt.figure(figsize=(9, 5))
    plt.plot(df.time_s, df["voltage_meas_V"], linewidth=0.5, label="Measured Voltage")
    plt.plot(df.time_s, df["voltage_pred_V"], "--", linewidth=0.5, label="Predicted Voltage")
    plt.title("Voltage Profile Measured vs Simulation")
    plt.xlabel("Time (s)")
    plt.ylabel("Voltage (V)")
    plt.legend()
    plt.tight_layout()
    volt_fig.savefig(os.path.join(outdir, "voltage_profile.png"), dpi=300)
    #plt.show()

    print(f"Saved all plots into folder: {outdir}")
#======================================

    C1_fn = pred.C1
    C2_fn = pred.C2

    soc_grid = np.linspace(0, 1, 200)
    T = 298.15  # set temperature or use measured

    C1_vals = np.array([C1_fn(z, T) for z in soc_grid])
    C2_vals = np.array([C2_fn(z, T) for z in soc_grid])

    plt.figure(figsize=(8, 4))
    plt.plot(soc_grid, C1_vals, label="C1(SOC)")
    # plt.plot(soc_grid, C2_vals, label="C2(SOC)")
    plt.xlabel("State of Charge (SOC)")
    plt.ylabel("Capacitance (Farads)")
    plt.title("RC Capacitance vs SOC")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "C1_vs_SOC.png"), dpi=200)
    # plt.show()

    plt.figure(figsize=(8, 4))
    plt.plot(soc_grid, C2_vals, label="C2(SOC)")
    plt.xlabel("State of Charge (SOC)")
    plt.ylabel("Capacitance (Farads)")
    plt.title("RC Capacitance vs SOC")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "C2_vs_SOC.png"), dpi=200)
    # plt.show()


#======================================
    # ---------- SAVE CSV — Voltage Profile ----------
    df_voltage = pd.DataFrame({
        "time_s": df["time_s"],
        "voltage_meas_V": df["voltage_meas_V"],
        "voltage_pred_V": df["voltage_pred_V"]
    })
    df_voltage.to_csv(os.path.join(outdir, "voltage_profile.csv"), index=False)
    print("Saved voltage profile CSV")


    # ---------- SAVE CSV — Voltage Error ----------
    df_error = pd.DataFrame({
        "time_s": df["time_s"],
        "voltage_error_V": df["voltage_meas_V"] - df["voltage_pred_V"]
    })
    df_error.to_csv(os.path.join(outdir, "voltage_error.csv"), index=False)
    print("Saved voltage error CSV")


    # ---------- SAVE main EKF output ----------
    df.to_csv(os.path.join(outdir, "ekf_full_output.csv"), index=False)
    print("Saved EKF full output CSV")

