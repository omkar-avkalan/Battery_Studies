#!/usr/bin/env python3
# test_tft.py - Simple test program for TFT display
import time
import sys
import os
from PIL import Image, ImageDraw, ImageFont
import board
import digitalio

# Try to import TFT library
try:
    import adafruit_rgb_display.st7735 as st7735
    TFT_AVAILABLE = True
    print("ST7735 library imported successfully")
except ImportError as e:
    TFT_AVAILABLE = False
    print(f"Failed to import ST7735 library: {e}")
    print("Please install: sudo pip3 install adafruit-circuitpython-rgb-display")

class SimpleTFTTest:
    def __init__(self, width=128, height=128):
        self.width = width
        self.height = height
        self.display = None
        
        if not TFT_AVAILABLE:
            print("TFT library not available. Running in simulation mode.")
            return
            
        try:
            # GPIO Pins for TFT Display
            cs_pin = digitalio.DigitalInOut(board.D8)   # CS - GPIO8 (CE0)
            dc_pin = digitalio.DigitalInOut(board.D24)  # DC - GPIO24
            reset_pin = digitalio.DigitalInOut(board.D25) # RST - GPIO25
            
            # Initialize SPI
            spi = board.SPI()
            
            # Initialize ST7735 display
            self.display = st7735.ST7735R(
                spi,
                rotation=0,
                cs=cs_pin,
                dc=dc_pin,
                rst=reset_pin,
                baudrate=24000000,
                width=width,
                height=height,
                x_offset=0,
                y_offset=0,
            )
            
            print(f"TFT Display initialized: {width}x{height}")
            print("GPIO Pins configured:")
            print(f"  CS  -> GPIO8  (Pin 24)")
            print(f"  DC  -> GPIO24 (Pin 18)")
            print(f"  RST -> GPIO25 (Pin 22)")
            
        except Exception as e:
            print(f"Failed to initialize TFT display: {e}")
            self.display = None
    
    def clear_screen(self, color=(0, 0, 0)):
        """Clear the display with a color"""
        if self.display:
            image = Image.new("RGB", (self.width, self.height), color)
            self.display.image(image)
    
    def show_test_pattern(self):
        """Display a test pattern to verify display works"""
        if not self.display:
            print("No display available. Showing simulated pattern.")
            return
            
        # Create image with test pattern
        image = Image.new("RGB", (self.width, self.height))
        draw = ImageDraw.Draw(image)
        
        # Draw borders
        draw.rectangle((0, 0, self.width-1, self.height-1), 
                      outline=(255, 255, 255), width=2)
        
        # Draw colored rectangles
        colors = [
            ((0, 0, 255), "Blue", 10, 10),
            ((0, 255, 0), "Green", 10, 30),
            ((255, 0, 0), "Red", 10, 50),
            ((255, 255, 0), "Yellow", 10, 70),
            ((255, 165, 0), "Orange", 10, 90),
            ((255, 255, 255), "White", 10, 110)
        ]
        
        for color, name, x, y in colors:
            draw.rectangle((x, y, x+20, y+10), fill=color)
            draw.text((x+25, y), name, fill=color)
        
        # Draw grid lines
        for i in range(0, self.width, 16):
            draw.line((i, 0, i, self.height), fill=(64, 64, 64))
        for i in range(0, self.height, 16):
            draw.line((0, i, self.width, i), fill=(64, 64, 64))
        
        # Center text
        draw.text((20, self.height//2 - 20), "TFT TEST", 
                 fill=(255, 255, 255))
        draw.text((15, self.height//2), "SUCCESSFUL!", 
                 fill=(0, 255, 0))
        
        # Display the image
        self.display.image(image)
        print("Test pattern displayed")
    
    def show_battery_demo(self):
        """Show a battery monitoring demo"""
        if not self.display:
            print("No display available. Cannot show demo.")
            return
            
        # Create image
        image = Image.new("RGB", (self.width, self.height), (0, 0, 0))
        draw = ImageDraw.Draw(image)
        
        # Try to load font
        try:
            font_small = ImageFont.truetype(
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 10)
            font_medium = ImageFont.truetype(
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
        except:
            font_small = ImageFont.load_default()
            font_medium = ImageFont.load_default()
        
        # Title
        draw.text((20, 5), "BATTERY MONITOR", fill=(0, 255, 0), font=font_medium)
        draw.text((35, 20), "DEMO DISPLAY", fill=(255, 255, 0), font=font_medium)
        
        # Draw battery icon
        self.draw_battery_icon(draw, 40, 40, 25, 12, 75)
        
        # Draw SOC gauge
        self.draw_soc_gauge(draw, self.width//2, 80, 25, 65)
        
        # Status text
        draw.text((10, 110), "SOC: 65%", fill=(0, 255, 0), font=font_small)
        draw.text((70, 110), "3.7V", fill=(255, 255, 0), font=font_small)
        
        draw.text((10, 120), "READY", fill=(0, 255, 0), font=font_small)
        
        # Display
        self.display.image(image)
        print("Battery demo displayed")
    
    def draw_battery_icon(self, draw, x, y, width, height, percent):
        """Draw battery icon"""
        # Outer rectangle
        draw.rectangle((x, y, x + width, y + height), 
                      outline=(255, 255, 255), width=1)
        
        # Terminal
        term_width = 3
        term_height = height // 2
        term_x = x + width
        term_y = y + (height - term_height) // 2
        draw.rectangle((term_x, term_y, term_x + term_width, term_y + term_height),
                      fill=(255, 255, 255))
        
        # Fill level
        fill_width = int((width - 4) * (percent / 100))
        if fill_width > 0:
            # Choose color based on percentage
            if percent <= 20:
                fill_color = (255, 0, 0)  # Red
            elif percent <= 40:
                fill_color = (255, 165, 0)  # Orange
            else:
                fill_color = (0, 255, 0)  # Green
            
            draw.rectangle((x + 2, y + 2, x + 2 + fill_width, y + height - 2),
                          fill=fill_color)
    
    def draw_soc_gauge(self, draw, x, y, radius, percent):
        """Draw SOC gauge"""
        # Outer circle
        draw.ellipse((x - radius, y - radius, x + radius, y + radius),
                    outline=(255, 255, 255), width=1)
        
        # Gauge arc
        start_angle = -90
        end_angle = start_angle + (360 * percent / 100)
        
        # Color based on SOC
        if percent <= 20:
            arc_color = (255, 0, 0)
        elif percent <= 40:
            arc_color = (255, 165, 0)
        elif percent <= 70:
            arc_color = (255, 255, 0)
        else:
            arc_color = (0, 255, 0)
        
        # Draw arc
        bbox = (x - radius + 4, y - radius + 4, 
                x + radius - 4, y + radius - 4)
        draw.arc(bbox, start_angle, end_angle, fill=arc_color, width=4)
        
        # Percentage text
        percent_text = f"{percent:.0f}%"
        bbox = draw.textbbox((0, 0), percent_text)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        
        draw.text((x - text_width // 2, y - text_height // 2),
                 percent_text, fill=arc_color)
    
    def show_color_bars(self):
        """Show color bars for display testing"""
        if not self.display:
            print("No display available.")
            return
            
        image = Image.new("RGB", (self.width, self.height))
        draw = ImageDraw.Draw(image)
        
        # Color bars
        colors = [
            (255, 0, 0),     # Red
            (0, 255, 0),     # Green
            (0, 0, 255),     # Blue
            (255, 255, 0),   # Yellow
            (255, 0, 255),   # Magenta
            (0, 255, 255),   # Cyan
            (255, 255, 255), # White
            (128, 128, 128), # Gray
        ]
        
        bar_height = self.height // len(colors)
        
        for i, color in enumerate(colors):
            y_start = i * bar_height
            y_end = (i + 1) * bar_height
            draw.rectangle((0, y_start, self.width, y_end), fill=color)
            draw.text((5, y_start + bar_height//2 - 5), 
                     f"R:{color[0]} G:{color[1]} B:{color[2]}", 
                     fill=(0, 0, 0) if color[0] + color[1] + color[2] > 384 else (255, 255, 255))
        
        self.display.image(image)
        print("Color bars displayed")
    
    def run_interactive_test(self):
        """Run interactive test sequence"""
        print("\n" + "="*50)
        print("TFT Display Interactive Test")
        print("="*50)
        
        if not self.display:
            print("\n⚠️  Display not initialized!")
            print("Running in simulation mode only.")
            print("\nIf you have a TFT display connected:")
            print("1. Check SPI is enabled: sudo raspi-config")
            print("2. Check wiring connections")
            print("3. Install library: sudo pip3 install adafruit-circuitpython-rgb-display")
            return
        
        print("\nStarting test sequence...")
        
        try:
            # 1. Clear to black
            print("\n1. Clearing screen to black...")
            self.clear_screen((0, 0, 0))
            time.sleep(1)
            
            # 2. Clear to white
            print("2. Clearing screen to white...")
            self.clear_screen((255, 255, 255))
            time.sleep(1)
            
            # 3. Show test pattern
            print("3. Showing test pattern...")
            self.show_test_pattern()
            time.sleep(3)
            
            # 4. Show color bars
            print("4. Showing color bars...")
            self.show_color_bars()
            time.sleep(3)
            
            # 5. Show battery demo
            print("5. Showing battery demo...")
            self.show_battery_demo()
            time.sleep(3)
            
            # 6. Fade through colors
            print("6. Cycling through colors...")
            fade_colors = [
                (255, 0, 0),    # Red
                (0, 255, 0),    # Green
                (0, 0, 255),    # Blue
                (255, 255, 0),  # Yellow
                (0, 255, 255),  # Cyan
                (255, 0, 255),  # Magenta
            ]
            
            for color in fade_colors:
                self.clear_screen(color)
                time.sleep(0.5)
            
            # 7. Final demo
            print("7. Final demo display...")
            self.show_battery_demo()
            
            print("\n✅ Test sequence completed successfully!")
            print("\nDisplay should show:")
            print("  - Battery icon (75% full)")
            print("  - SOC gauge (65%)")
            print("  - Status text")
            
        except KeyboardInterrupt:
            print("\n\nTest interrupted by user")
        except Exception as e:
            print(f"\n❌ Error during test: {e}")
        finally:
            # Clear to black at the end
            self.clear_screen((0, 0, 0))
            print("\nScreen cleared to black")


def check_system():
    """Check system requirements"""
    print("="*50)
    print("System Requirements Check")
    print("="*50)
    
    checks = {
        "Python 3": sys.version_info.major == 3,
        "Raspberry Pi": os.path.exists('/proc/device-tree/model'),
        "SPI Enabled": os.path.exists('/dev/spidev0.0'),
    }
    
    all_ok = True
    for check_name, status in checks.items():
        status_str = "✅ OK" if status else "❌ FAILED"
        print(f"{check_name}: {status_str}")
        if not status:
            all_ok = False
    
    if os.path.exists('/proc/device-tree/model'):
        with open('/proc/device-tree/model', 'r') as f:
            model = f.read().strip()
        print(f"\nDevice Model: {model}")
    
    print(f"\nOverall Status: {'✅ READY' if all_ok else '❌ ISSUES DETECTED'}")
    return all_ok


def main():
    """Main test function"""
    print("TFT Display Test Program")
    print("="*50)
    
    # Check system
    if not check_system():
        print("\n⚠️  Some requirements not met.")
        print("Continue anyway? (y/n): ", end="")
        if input().lower() != 'y':
            return
    
    # Initialize display
    print("\nInitializing TFT display...")
    tft = SimpleTFTTest(width=128, height=128)
    
    # Run interactive test
    tft.run_interactive_test()
    
    print("\n" + "="*50)
    print("Test Complete!")
    print("="*50)
    print("\nNext steps:")
    print("1. If display shows correctly, your setup is working!")
    print("2. If not, check:")
    print("   - Wiring connections")
    print("   - SPI interface (sudo raspi-config)")
    print("   - Library installation")
    print("\nRun: python3 test_tft.py to test again")


if __name__ == "__main__":
    main()