import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import thevenin as thev

# ================= USER SETTINGS =================
CSV_MEAS    = "rearranged_dis_25.csv"     # your HPPC CSV
PARAMS_YAML = "Para_1c_25_dis.yaml"      # params yaml for this condition
TEMP_C      = 25.0                    # only used if your model needs it elsewhere
I_REST_THR  = 0.02                    # A, |I| below = REST
MIN_SEG_S   = 2.0                     # s, merge/remove very short flickers
MAX_STEP    = 0.5                     # s, solver max internal step
# =================================================

def pick_column(columns, *needles):
    for c in columns:
        s = c.lower()
        if all(n.lower() in s for n in needles):
            return c
    raise KeyError(f"Could not find column with {needles} in {list(columns)}")

# ---------- Load the measured HPPC ----------
meas = pd.read_csv(CSV_MEAS)
time_col = pick_column(meas.columns, "time")
volt_col = pick_column(meas.columns, "volt")
curr_col = pick_column(meas.columns, "curr")

t = pd.to_numeric(meas[time_col], errors="coerce").to_numpy()
v = pd.to_numeric(meas[volt_col], errors="coerce").to_numpy()
i = pd.to_numeric(meas[curr_col], errors="coerce").to_numpy()

mask = np.isfinite(t) & np.isfinite(v) & np.isfinite(i)
t, v, i = t[mask], v[mask], i[mask]
order = np.argsort(t)
t, v, i = t[order], v[order], i[order]

t = t - t[0]                            # start at 0 s
dt = np.diff(t, prepend=t[0])
if t[-1] <= 0:
    raise ValueError("Time trace has zero span.")

# ---------- Segment into PULSE / REST windows ----------
is_rest = np.abs(i) < I_REST_THR

segments = []   # list of dicts: {type, t0, t1, dur, I_set}
start = 0
state = is_rest[0]
for k in range(1, len(t)):
    if is_rest[k] != state:
        # close previous segment at k-1
        t0, t1 = t[start], t[k-1]
        dur = max(0.0, t1 - t0)
        if dur > 0:
            I_set = float(np.mean(i[start:k]))  # mean over segment
            seg_type = "rest" if state else "pulse"
            segments.append({"type": seg_type, "t0": t0, "t1": t1, "dur": dur, "I_set": I_set})
        # start new
        start = k
        state = is_rest[k]
# tail
t0, t1 = t[start], t[-1]
dur = max(0.0, t1 - t0)
if dur > 0:
    I_set = float(np.mean(i[start:]))
    seg_type = "rest" if state else "pulse"
    segments.append({"type": seg_type, "t0": t0, "t1": t1, "dur": dur, "I_set": I_set})

# ---------- Clean up tiny segments (merge flickers) ----------
cleaned = []
for seg in segments:
    if seg["dur"] < MIN_SEG_S and cleaned:
        # merge into previous segment by extending end and recomputing mean
        prev = cleaned[-1]
        # recompute mean current weighted by duration
        dur_sum = prev["dur"] + seg["dur"]
        if dur_sum > 0:
            I_mean = (prev["I_set"]*prev["dur"] + seg["I_set"]*seg["dur"]) / dur_sum
        else:
            I_mean = prev["I_set"]
        prev["t1"]  = seg["t1"]
        prev["dur"] = dur_sum
        prev["I_set"] = float(I_mean)
    else:
        cleaned.append(seg)

segments = cleaned

# For rests, force current exactly 0 A (optional but helps)
for seg in segments:
    if seg["type"] == "rest":
        seg["I_set"] = 0.0

# ✅ Build the (I_set, dur) list that mirrors the HPPC program
steps = [(seg["I_set"], seg["dur"]) for seg in segments]

# ---------- Build Experiment using those segments ----------
expr = thev.Experiment(max_step=MAX_STEP)
for idx, seg in enumerate(segments, start=1):
    expr.add_step('current_A', seg["I_set"], (seg["dur"], 1.0))
# (If your thevenin supports voltage limit, you can add limits=('voltage_V', 3.0) to each add_step)

# Print a compact summary for sanity check
print("\n== HPPC Step Table (from CSV) ==")
for k, seg in enumerate(segments, 1):
    print(f"{k:02d}  {seg['type'].upper():5s}  I={seg['I_set']:7.3f} A   dur={seg['dur']:7.2f} s")

# ---------- Run simulation ----------
sim = thev.Simulation(PARAMS_YAML)
soln = sim.run(expr)
sim_df = pd.DataFrame(soln.vars)

# ---------- Compare sim vs measured ----------
Vsim_on_meas = np.interp(t,
                        pd.to_numeric(sim_df["time_s"], errors="coerce").to_numpy(),
                        pd.to_numeric(sim_df["voltage_V"], errors="coerce").to_numpy())
err = Vsim_on_meas - v

RMSE = float(np.sqrt(np.mean(err**2)))
MAE  = float(np.mean(np.abs(err)))
BIAS = float(np.mean(err))
print(f"\n[metrics] RMSE={RMSE*1e3:.1f} mV, MAE={MAE*1e3:.1f} mV, Bias={BIAS*1e3:.1f} mV")

# ---------- Plots ----------
plt.figure(figsize=(9.2,5.2))
plt.plot(t/3600, v, label="Measured", lw=1.6)
plt.plot(t/3600, Vsim_on_meas, label="Simulated", lw=1.6)
plt.xlabel("Time [h]"); plt.ylabel("Voltage [V]")
plt.title(f"Voltage vs Time (HPPC replay)\nRMSE={RMSE*1e3:.1f} mV, MAE={MAE*1e3:.1f} mV, Bias={BIAS*1e3:.1f} mV")
plt.grid(True); plt.legend(); plt.tight_layout(); plt.show()

plt.figure(figsize=(9.2,3.2))
plt.plot(t/3600, err*1e3, lw=1.0)
plt.axhline(0, color='k', lw=0.8)
plt.xlabel("Time [h]"); plt.ylabel("Error [mV]"); plt.title("Sim − Meas")
plt.grid(True); plt.tight_layout(); plt.show()

# ----- Step-end error table -----
# Cumulative end times (relative seconds)
end_times_s = np.cumsum([dur for (_, dur) in steps])

# Interpolate measured & simulated voltages at those end times
Vexp_end = np.interp(end_times_s, t, v)
Vsim_end = np.interp(
    end_times_s,
    pd.to_numeric(sim_df["time_s"], errors="coerce").to_numpy(),
    pd.to_numeric(sim_df["voltage_V"], errors="coerce").to_numpy()
)

err_end    = Vsim_end - Vexp_end
errpct_end = 100.0 * err_end / np.clip(Vexp_end, 1e-9, None)

step_table = pd.DataFrame({
    "Time_s":      end_times_s,
    "Voltage_exp": Vexp_end,
    "Voltage_ECM": Vsim_end,
    "Error":       err_end,
    "Error%":      errpct_end
})

print("\n=== Step-end error table (last 10) ===")
print(step_table.tail(10).to_string(index=False, formatters={
    "Time_s":      lambda x: f"{x:9.2f}",
    "Voltage_exp": lambda x: f"{x:6.3f}",
    "Voltage_ECM": lambda x: f"{x:6.3f}",
    "Error":       lambda x: f"{x:+.4f}",
    "Error%":      lambda x: f"{x:+6.2f}"
}))

# Save to CSV
out_csv = "step_end_errors.csv"
step_table.to_csv(out_csv, index=False)
print(f"Saved step-end table → {out_csv}")
